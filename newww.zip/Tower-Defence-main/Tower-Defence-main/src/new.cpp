#include <SFML/Graphics.hpp>
#include <iostream>

// Button class
class Button {
private:
    sf::RectangleShape shape;
    sf::Text text;
    sf::Font font;

public:
    Button(float x, float y, float width, float height, const std::string& buttonText) {
        shape.setPosition(x, y);
        shape.setSize(sf::Vector2f(width, height));
        shape.setFillColor(sf::Color::Blue);

        if (!font.loadFromFile("ariali.ttf")) {
            std::cerr << "Failed to load font!" << std::endl;
        }

        text.setFont(font);
        text.setString(buttonText);
        text.setCharacterSize(24);
        text.setFillColor(sf::Color::White);
        text.setPosition(
            x + (width - text.getLocalBounds().width) / 2,
            y + (height - text.getLocalBounds().height) / 2
        );
    }

    void draw(sf::RenderWindow& window) {
        window.draw(shape);
        window.draw(text);
    }

    bool isClicked(sf::Vector2i mousePos) {
        return shape.getGlobalBounds().contains(static_cast<sf::Vector2f>(mousePos));
    }
};

// Main application class
class Application {
private:
    sf::RenderWindow window;
    Button button;
    bool whiteScreen;

public:
    Application()
        : window(sf::VideoMode(800, 600), "Button Example"), button(300, 250, 200, 50, "Click Me"), whiteScreen(false) {}

    void run() {
        while (window.isOpen()) {
            handleEvents();
            update();
            render();
        }
    }

private:
    void handleEvents() {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }

            if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
                sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                if (button.isClicked(mousePos)) {
                    whiteScreen = true;
                }
            }
        }
    }

    void update() {
        // Add any game logic here if needed
    }

    void render() {
        if (whiteScreen) {
            window.clear(sf::Color::White);
        } else {
            window.clear(sf::Color::Black);
            button.draw(window);
        }
        window.display();
    }
};

int main() {
    Application app;
    app.run();
    return 0;
}
