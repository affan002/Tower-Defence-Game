#include "game.hpp"

int main(){
    Game game;
    game.Run();
    return 0;
}