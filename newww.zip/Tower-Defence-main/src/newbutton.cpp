#include <SFML/Graphics.hpp>
#include <iostream>
#include "game.hpp"
// Button class
class bbutton {
private:
    sf::RectangleShape shape;
    sf::Text text;
    sf::Font font;

public:
    bbutton(float x, float y, float width, float height, const std::string& buttonText) {
        shape.setPosition(x, y);
        shape.setSize(sf::Vector2f(width, height));
        shape.setFillColor(sf::Color::Blue);

        if (!font.loadFromFile("arial.ttf")) {
            std::cerr << "Failed to load font!" << std::endl;
        }

        text.setFont(font);
        text.setString(buttonText);
        text.setCharacterSize(24);
        text.setFillColor(sf::Color::White);
        text.setPosition(
            x + (width - text.getLocalBounds().width) / 2,
            y + (height - text.getLocalBounds().height) / 2
        );
    }

    void draw(sf::RenderWindow& window) {
        window.draw(shape);
        window.draw(text);
    }

    bool isClicked(sf::Vector2i mousePos) {
        return shape.getGlobalBounds().contains(static_cast<sf::Vector2f>(mousePos));
    }
};


// Main application class
class Application {
private:
    sf::RenderWindow window;
    bbutton startButton;
    bbutton quitButton;
    sf::Texture backgroundTexture;
    sf::Sprite backgroundSprite;
    Game game;

public:
    Application()
        : window(sf::VideoMode(800, 600), "Button Example"),
          startButton(300, 200, 200, 50, "Start"),
          quitButton(300, 300, 200, 50, "Quit") {
        if (!backgroundTexture.loadFromFile("background.png")) {
            std::cerr << "Failed to load background image!" << std::endl;
        }
        backgroundSprite.setTexture(backgroundTexture);
    }

    void run() {
        while (window.isOpen()) {
            handleEvents();
            update();
            render();
        }
    }

private:
    void handleEvents() {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }

            if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
                sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                if (startButton.isClicked(mousePos)) {
                    
                }
                if (quitButton.isClicked(mousePos)) {
                    window.close();
                }
            }
        }
    }

    void update() {
        // Add any logic here if needed
    }

    void render() {
        window.clear();
        window.draw(backgroundSprite);
        startButton.draw(window);
        quitButton.draw(window);
        window.display();
    }
};
